<?php

/* @WebProfiler/Icon/forward.svg */
class __TwigTemplate_23d13b797e581ed0c1ec49ee7d17a95a0c1bd54b4247730ca4ef6e61e2bdb703 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e4d47d276d0d6bebe03ae85cb9074dab1a1e99b48cabd584bc08689514e0f6e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4e4d47d276d0d6bebe03ae85cb9074dab1a1e99b48cabd584bc08689514e0f6e->enter($__internal_4e4d47d276d0d6bebe03ae85cb9074dab1a1e99b48cabd584bc08689514e0f6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        $__internal_c7df16fd1d787c0d0e2fe2925d413796011a64d14abe82ef77a6b4cc99908bc2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7df16fd1d787c0d0e2fe2925d413796011a64d14abe82ef77a6b4cc99908bc2->enter($__internal_c7df16fd1d787c0d0e2fe2925d413796011a64d14abe82ef77a6b4cc99908bc2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
";
        
        $__internal_4e4d47d276d0d6bebe03ae85cb9074dab1a1e99b48cabd584bc08689514e0f6e->leave($__internal_4e4d47d276d0d6bebe03ae85cb9074dab1a1e99b48cabd584bc08689514e0f6e_prof);

        
        $__internal_c7df16fd1d787c0d0e2fe2925d413796011a64d14abe82ef77a6b4cc99908bc2->leave($__internal_c7df16fd1d787c0d0e2fe2925d413796011a64d14abe82ef77a6b4cc99908bc2_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/forward.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
", "@WebProfiler/Icon/forward.svg", "/var/www/html/ledser/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Icon/forward.svg");
    }
}

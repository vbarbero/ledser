<?php

/* AppBundle:partials:footer.html.twig */
class __TwigTemplate_a2cde78cbb3598fe7fe17fdcbe11c1c0de4f63e69978a0e6a0c637afceb7dc2e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_915520d552b5a447f3569c1e631d78e8d5e548321da5ac1114960451d714874d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_915520d552b5a447f3569c1e631d78e8d5e548321da5ac1114960451d714874d->enter($__internal_915520d552b5a447f3569c1e631d78e8d5e548321da5ac1114960451d714874d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:partials:footer.html.twig"));

        $__internal_99e88d0210835cfdffae9b93ad3b03b27028aafc3566c0f9d6da3da3f8c92752 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_99e88d0210835cfdffae9b93ad3b03b27028aafc3566c0f9d6da3da3f8c92752->enter($__internal_99e88d0210835cfdffae9b93ad3b03b27028aafc3566c0f9d6da3da3f8c92752_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:partials:footer.html.twig"));

        
        $__internal_915520d552b5a447f3569c1e631d78e8d5e548321da5ac1114960451d714874d->leave($__internal_915520d552b5a447f3569c1e631d78e8d5e548321da5ac1114960451d714874d_prof);

        
        $__internal_99e88d0210835cfdffae9b93ad3b03b27028aafc3566c0f9d6da3da3f8c92752->leave($__internal_99e88d0210835cfdffae9b93ad3b03b27028aafc3566c0f9d6da3da3f8c92752_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:partials:footer.html.twig";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AppBundle:partials:footer.html.twig", "/var/www/html/ledser/src/AppBundle/Resources/views/partials/footer.html.twig");
    }
}
